package com.meowhome;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeowHomeApplicationTests {

	@Test
	void contextLoads() {
	}

}
